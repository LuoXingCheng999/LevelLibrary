// LevelLibrary 背景高斯模糊（两趟可分离卷积：先横向再纵向）
// 挂在专用相机上做 OnRenderImage 后处理，结果被 UI 当背景显示。
Shader "LevelLibrary/BackgroundBlur" {
    Properties {
        _MainTex ("Texture", 2D) = "white" {}
        _Radius ("Radius", Float) = 8
        _Step ("Step", Float) = 1
    }
    SubShader {
        Cull Off ZWrite Off ZTest Always

        // 第一趟：横向
        Pass {
            Name "HORIZONTAL"
            CGPROGRAM
            #pragma vertex vert_img
            #pragma fragment fragH
            #include "UnityCG.cginc"

            sampler2D _MainTex;
            float4 _MainTex_TexelSize;
            float _Radius;
            float _Step;

            fixed4 BlurAt(float2 uv, float2 dir) {
                // 9 抽样高斯近似（权重和为 1）
                float w[5] = { 0.2270270270, 0.1945945946, 0.1216216216, 0.0540540541, 0.0162162162 };
                fixed4 c = tex2D(_MainTex, uv) * w[0];
                [unroll]
                for (int k = 1; k < 5; k++) {
                    float2 off = dir * ((float)k * _Radius + 0.5);
                    c += tex2D(_MainTex, uv + off) * w[k];
                    c += tex2D(_MainTex, uv - off) * w[k];
                }
                return c;
            }

            fixed4 fragH (v2f_img i) : SV_Target {
                float2 dir = float2(1.0, 0.0) * _MainTex_TexelSize.xy * _Step;
                return BlurAt(i.uv, dir);
            }
            ENDCG
        }

        // 第二趟：纵向
        Pass {
            Name "VERTICAL"
            CGPROGRAM
            #pragma vertex vert_img
            #pragma fragment fragV
            #include "UnityCG.cginc"

            sampler2D _MainTex;
            float4 _MainTex_TexelSize;
            float _Radius;
            float _Step;

            fixed4 BlurAt(float2 uv, float2 dir) {
                float w[5] = { 0.2270270270, 0.1945945946, 0.1216216216, 0.0540540541, 0.0162162162 };
                fixed4 c = tex2D(_MainTex, uv) * w[0];
                [unroll]
                for (int k = 1; k < 5; k++) {
                    float2 off = dir * ((float)k * _Radius + 0.5);
                    c += tex2D(_MainTex, uv + off) * w[k];
                    c += tex2D(_MainTex, uv - off) * w[k];
                }
                return c;
            }

            fixed4 fragV (v2f_img i) : SV_Target {
                float2 dir = float2(0.0, 1.0) * _MainTex_TexelSize.xy * _Step;
                return BlurAt(i.uv, dir);
            }
            ENDCG
        }
    }
    Fallback Off
}
